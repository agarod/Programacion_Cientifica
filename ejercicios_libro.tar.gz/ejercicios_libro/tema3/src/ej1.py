#!/usr/bin/python
# encoding: utf-8

'''
---------------------------------------
    Nombre: Ardiel Garcia Rodriguez
    Practica: Move the last line of this program to the to, so the function
    call appears before the definitions. Run the programand see that error 
    message you get.
    Email: alu0100266382@ull.edu.es
    
---------------------------------------
'''

repeat_lyrics()

def print_lyrics():
    print "I'm a lumberjack, and I'm okay"
    print "I sleep all night and I work all day"

def repeat_lyrics():
    print_lyrics()
    print_lyrics()


