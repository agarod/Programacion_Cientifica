#!/usr/bin/python
# encoding: utf-8

'''
---------------------------------------
    Nombre: Ardiel Garcia Rodriguez
    Practica: Write a function named right_justify thattajes a string named
    s as a parameter and prints the string with enough leading spaces so 
    that the last letter of the string is in column 70 of the dislay.
    Email: alu0100266382@ull.edu.es
    
---------------------------------------
'''

def right_justify(s):
    print "%70s" % s


#s = str(raw_input('Introduzca una cadena de caracteres:' ))
right_justify('allen')



